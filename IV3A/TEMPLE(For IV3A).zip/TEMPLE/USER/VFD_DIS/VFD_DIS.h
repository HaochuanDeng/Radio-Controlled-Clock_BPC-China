#ifndef __VFD_DIS_H
#define __VFD_DIS_H

#include "stm32f10x.h"
#include "define.h"
#include "GPIO.h"
#include "DELAY.h"

void VFD_DIS_FUN  (uint8_t *DATA);
void VFD_ALL_BLANK(void);
#endif
