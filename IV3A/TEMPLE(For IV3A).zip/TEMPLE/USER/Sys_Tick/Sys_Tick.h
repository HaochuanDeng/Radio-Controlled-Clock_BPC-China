#ifndef __SYS_TICK_H
#define __SYS_TICK_H

#include "stm32f10x.h"

uint32_t Sys_Tick_Config(uint32_t Ticks);

#endif
