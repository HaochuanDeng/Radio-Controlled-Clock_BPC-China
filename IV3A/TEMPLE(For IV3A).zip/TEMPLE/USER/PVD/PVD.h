#ifndef __PVD_H
#define __PVD_H

#include "stm32f10x.h"
#include "define.h"

void PVD_Config(void);

#endif
