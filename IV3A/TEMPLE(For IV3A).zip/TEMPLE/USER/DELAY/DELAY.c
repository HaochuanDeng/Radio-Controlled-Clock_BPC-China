#include "DELAY.h"

//ms��ʱ����
void Delayms(u16 ms)
{
  u16 i,j;
  u8 k;
	
  for(i=0;i<ms;i++)
    for(j=0;j<0x0500;j++) 
	      k++;
}

//s��ʱ����
void Delays(u8 s)
{
	u32 x;
	
	for(x=s*6000; x>0; x--)
	   Delayms(1);
}
