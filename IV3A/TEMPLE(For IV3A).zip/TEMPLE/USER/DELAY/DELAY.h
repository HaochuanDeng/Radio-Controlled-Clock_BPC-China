#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f10x.h"

void Delayms(u16 ms);
void Delays (u8 s);

#endif
