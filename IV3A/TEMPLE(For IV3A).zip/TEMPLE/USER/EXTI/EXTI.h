#ifndef __EXTI_H
#define __EXTI_H

#include "stm32f10x.h"
#include "define.h"

void EXTI_Key_Config(void);

#endif
