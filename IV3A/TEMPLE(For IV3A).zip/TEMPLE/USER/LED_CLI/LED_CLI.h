#ifndef __LED_CLI_H
#define __LED_CLI_H

#include "stm32f10x.h"
#include "define.h"
#include "GPIO.h"
#include "DELAY.h"

void LED_CLI_Frame_Head(void);
void LED_CLI_Failed    (void);
void LED_CLI_OK        (void);
void LED_CLI_Abort     (void);

#endif
