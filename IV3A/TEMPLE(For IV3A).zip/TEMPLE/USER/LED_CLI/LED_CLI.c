#include "LED_CLI.h"

//��⵽֡ͷ
void LED_CLI_Frame_Head(void)
{
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
}

//����ʧ��
void LED_CLI_Failed(void)
{
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
}

//����ɹ�
void LED_CLI_OK(void)
{
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
	LED_CLI_ON;
	Delayms(3000);
	LED_CLI_OFF;
	Delayms(1500);
}

//���뱻�ж�
void LED_CLI_Abort(void)
{
	LED_CLI_OFF;
	Delayms(250);
	LED_CLI_ON;
	Delayms(500);
	LED_CLI_OFF;
	Delayms(250);
	LED_CLI_ON;
	Delayms(500);
	LED_CLI_OFF;
	Delayms(250);
	LED_CLI_ON;
	Delayms(500);
	LED_CLI_OFF;
	Delayms(250);
	LED_CLI_ON;
	Delayms(500);
	LED_CLI_OFF;
	Delayms(250);
}
