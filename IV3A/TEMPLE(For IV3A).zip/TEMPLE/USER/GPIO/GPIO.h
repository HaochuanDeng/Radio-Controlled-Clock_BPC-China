#ifndef __GPIO_H
#define __GPIO_H

#include "stm32f10x.h"
#include "define.h"

//ʹ��ֱ�Ӳ����Ĵ����ķ�������IO
#define digitalHi(p,i)     {p->BSRR =i;}//���Ϊ�ߵ�ƽ
#define digitalLo(p,i)     {p->BRR  =i;}//����͵�ƽ
//#define digitalToggle(p,i) {p->ODR ^=i;}//�����ת״̬

//�������IO�ĺ�
//#define LED_SEC_TOGGLE     digitalToggle(LED_SEC_GPIO_PORT,LED_SEC_GPIO_PIN)
#define LED_SEC_ON         digitalHi    (LED_SEC_GPIO_PORT,LED_SEC_GPIO_PIN)
#define LED_SEC_OFF        digitalLo    (LED_SEC_GPIO_PORT,LED_SEC_GPIO_PIN)
#define LED_CLI_ON         digitalHi    (LED_CLI_GPIO_PORT,LED_CLI_GPIO_PIN)
#define LED_CLI_OFF        digitalLo    (LED_CLI_GPIO_PORT,LED_CLI_GPIO_PIN)
#define LE_0_ON            digitalHi    (LE_GPIO_PORT     ,LE_GPIO_PIN_0)
#define LE_0_OFF           digitalLo    (LE_GPIO_PORT     ,LE_GPIO_PIN_0)
#define LE_1_ON            digitalHi    (LE_GPIO_PORT     ,LE_GPIO_PIN_1)
#define LE_1_OFF           digitalLo    (LE_GPIO_PORT     ,LE_GPIO_PIN_1)
#define LE_2_ON            digitalHi    (LE_GPIO_PORT     ,LE_GPIO_PIN_2)
#define LE_2_OFF           digitalLo    (LE_GPIO_PORT     ,LE_GPIO_PIN_2)
#define LE_3_ON            digitalHi    (LE_GPIO_PORT     ,LE_GPIO_PIN_3)
#define LE_3_OFF           digitalLo    (LE_GPIO_PORT     ,LE_GPIO_PIN_3)

void NTCO_GPIO_Config   (void);
void LED_SEC_GPIO_Config(void);
void HC573_GPIO_Config  (void);
void LED_CLI_GPIO_Config(void);

#endif
