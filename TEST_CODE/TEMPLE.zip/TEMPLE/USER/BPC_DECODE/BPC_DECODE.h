#ifndef __BPC_DECODE_H
#define __BPC_DECODE_H

#include "stm32f10x.h"
#include "define.h"

uint8_t BPC_DECODE(uint8_t *Buff, uint8_t *DATA);

#endif
